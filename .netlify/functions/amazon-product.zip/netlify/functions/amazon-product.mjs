
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/utils/amazon-paapi.ts
var amazon_paapi_exports = {};
__export(amazon_paapi_exports, {
  getProduct: () => getProduct,
  getProductsByASINs: () => getProductsByASINs
});
import crypto from "crypto";
function hmacSha256(key, data) {
  return crypto.createHmac("sha256", key).update(data, "utf8").digest();
}
function sha256(data) {
  return crypto.createHash("sha256").update(data, "utf8").digest("hex");
}
function getSignatureKey(key, dateStamp, region, service) {
  const kDate = hmacSha256(`AWS4${key}`, dateStamp);
  const kRegion = hmacSha256(kDate, region);
  const kService = hmacSha256(kRegion, service);
  return hmacSha256(kService, "aws4_request");
}
function signRequest(payload, accessKey, secretKey) {
  const now = /* @__PURE__ */ new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp = amzDate.substring(0, 8);
  const canonicalUri = "/paapi5/getitems";
  const canonicalQuerystring = "";
  const contentType = "application/json; charset=UTF-8";
  const target = "com.amazon.paapi5.v1.ProductAdvertisingAPIv1.GetItems";
  const headers = {
    "content-encoding": "amz-1.0",
    "content-type": contentType,
    "host": HOST,
    "x-amz-date": amzDate,
    "x-amz-target": target
  };
  const signedHeaders = Object.keys(headers).sort().join(";");
  const canonicalHeaders = Object.keys(headers).sort().map((k) => `${k}:${headers[k]}
`).join("");
  const payloadHash = sha256(payload);
  const canonicalRequest = [
    "POST",
    canonicalUri,
    canonicalQuerystring,
    canonicalHeaders,
    signedHeaders,
    payloadHash
  ].join("\n");
  const credentialScope = `${dateStamp}/${REGION}/${SERVICE}/aws4_request`;
  const stringToSign = [
    "AWS4-HMAC-SHA256",
    amzDate,
    credentialScope,
    sha256(canonicalRequest)
  ].join("\n");
  const signingKey = getSignatureKey(secretKey, dateStamp, REGION, SERVICE);
  const signature = hmacSha256(signingKey, stringToSign).toString("hex");
  const authorization = `AWS4-HMAC-SHA256 Credential=${accessKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;
  return {
    ...headers,
    "Authorization": authorization
  };
}
async function getProductsByASINs(asins) {
  const accessKey = process.env.AMAZON_ACCESS_KEY;
  const secretKey = process.env.AMAZON_SECRET_KEY;
  const tag = process.env.AMAZON_ASSOCIATE_TAG || "glowpicked0c-20";
  if (!accessKey || !secretKey) {
    console.warn("[PA-API] Missing credentials. Set AMAZON_ACCESS_KEY and AMAZON_SECRET_KEY.");
    return asins.map((asin) => ({
      asin,
      title: "",
      imageUrl: "",
      imageLargeUrl: "",
      price: "",
      currency: "USD",
      rating: null,
      totalReviews: null,
      url: `https://www.amazon.com/dp/${asin}/ref=nosim?tag=${tag}`,
      available: false
    }));
  }
  const results = [];
  for (let i = 0; i < asins.length; i += 10) {
    const batch = asins.slice(i, i + 10);
    const payload = JSON.stringify({
      ItemIds: batch,
      Resources: [
        "Images.Primary.Large",
        "Images.Primary.Medium",
        "ItemInfo.Title",
        "Offers.Listings.Price",
        "Offers.Listings.Availability.Type",
        "CustomerReviews.Count",
        "CustomerReviews.StarRating"
      ],
      PartnerTag: tag,
      PartnerType: "Associates",
      Marketplace: "www.amazon.com"
    });
    const headers = signRequest(payload, accessKey, secretKey);
    try {
      const response = await fetch(`https://${HOST}/paapi5/getitems`, {
        method: "POST",
        headers,
        body: payload
      });
      if (!response.ok) {
        const errorText = await response.text();
        console.error(`[PA-API] Error ${response.status}: ${errorText}`);
        batch.forEach((asin) => results.push({
          asin,
          title: "",
          imageUrl: "",
          imageLargeUrl: "",
          price: "",
          currency: "USD",
          rating: null,
          totalReviews: null,
          url: `https://www.amazon.com/dp/${asin}/ref=nosim?tag=${tag}`,
          available: false
        }));
        continue;
      }
      const data = await response.json();
      if (data.ItemsResult?.Items) {
        for (const item of data.ItemsResult.Items) {
          const listing = item.Offers?.Listings?.[0];
          results.push({
            asin: item.ASIN,
            title: item.ItemInfo?.Title?.DisplayValue || "",
            imageUrl: item.Images?.Primary?.Medium?.URL || "",
            imageLargeUrl: item.Images?.Primary?.Large?.URL || "",
            price: listing?.Price?.DisplayAmount || "",
            currency: listing?.Price?.Currency || "USD",
            rating: item.CustomerReviews?.StarRating?.Value ?? null,
            totalReviews: item.CustomerReviews?.Count ?? null,
            url: `https://www.amazon.com/dp/${item.ASIN}/ref=nosim?tag=${tag}`,
            available: listing?.Availability?.Type === "Now"
          });
        }
      }
      if (i + 10 < asins.length) {
        await new Promise((r) => setTimeout(r, 1100));
      }
    } catch (err) {
      console.error(`[PA-API] Fetch error:`, err);
      batch.forEach((asin) => results.push({
        asin,
        title: "",
        imageUrl: "",
        imageLargeUrl: "",
        price: "",
        currency: "USD",
        rating: null,
        totalReviews: null,
        url: `https://www.amazon.com/dp/${asin}/ref=nosim?tag=${tag}`,
        available: false
      }));
    }
  }
  return results;
}
async function getProduct(asin) {
  const [product] = await getProductsByASINs([asin]);
  return product;
}
var HOST, REGION, SERVICE;
var init_amazon_paapi = __esm({
  "src/utils/amazon-paapi.ts"() {
    HOST = "webservices.amazon.com";
    REGION = process.env.AMAZON_REGION || "us-east-1";
    SERVICE = "ProductAdvertisingAPI";
  }
});

// netlify/functions/amazon-product.ts
var cache = /* @__PURE__ */ new Map();
var CACHE_TTL = 60 * 60 * 1e3;
var amazon_product_default = async (req, context) => {
  const url = new URL(req.url);
  const asins = url.searchParams.get("asins")?.split(",").slice(0, 10) || [];
  if (asins.length === 0) {
    return new Response(JSON.stringify({ error: "Missing ?asins= parameter" }), {
      status: 400,
      headers: { "Content-Type": "application/json" }
    });
  }
  const accessKey = process.env.AMAZON_ACCESS_KEY;
  const secretKey = process.env.AMAZON_SECRET_KEY;
  const tag = process.env.AMAZON_ASSOCIATE_TAG || "glowpicked0c-20";
  if (!accessKey || !secretKey) {
    return new Response(JSON.stringify({
      error: "PA-API not configured yet",
      message: "Need 3 qualifying sales to get API access",
      products: asins.map((asin) => ({
        asin,
        imageUrl: null,
        price: null,
        url: `https://www.amazon.com/dp/${asin}/ref=nosim?tag=${tag}`
      }))
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=86400",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
  const cacheKey = asins.sort().join(",");
  const cached = cache.get(cacheKey);
  if (cached && cached.expires > Date.now()) {
    return new Response(JSON.stringify(cached.data), {
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=3600",
        "Access-Control-Allow-Origin": "*",
        "X-Cache": "HIT"
      }
    });
  }
  try {
    const { getProductsByASINs: getProductsByASINs2 } = await Promise.resolve().then(() => (init_amazon_paapi(), amazon_paapi_exports));
    const products = await getProductsByASINs2(asins);
    const responseData = {
      products: products.map((p) => ({
        asin: p.asin,
        title: p.title,
        imageUrl: p.imageUrl,
        price: p.price,
        url: p.url,
        available: p.available
      }))
    };
    cache.set(cacheKey, { data: responseData, expires: Date.now() + CACHE_TTL });
    return new Response(JSON.stringify(responseData), {
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=3600",
        "Access-Control-Allow-Origin": "*",
        "X-Cache": "MISS"
      }
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
var config = {
  path: "/api/amazon-product"
};
export {
  config,
  amazon_product_default as default
};
